﻿#include <stdbool.h>

#include "PT32x0xx.h"
#include "CMix_board.h"
#include "CMix_control.h"

static void CMix_MainLoop(CMix_ControlContext *ctx);

int main(void)
{
    CMix_ControlContext control_ctx;

    CMix_SystemInit();
    CMix_ControlInit(&control_ctx);

    CMix_MainLoop(&control_ctx);

    return 0;
}

static void CMix_MainLoop(CMix_ControlContext *ctx)
{
    bool run = true;

    while (run)
    {
        CMix_ControlUpdate(ctx);
        __NOP();
    }
}
